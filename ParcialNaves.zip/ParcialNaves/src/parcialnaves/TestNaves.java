/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parcialnaves;

import config.Categoria;
import config.FilePaths;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import models.NaveEspacial;
import services.Inventario;

/**
 *
 * @author Gerónimo
 */
public class TestNaves {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

//        nombre del repositorio: Apellido.Nombre.SP.ProgII321
        
        
//        AGREGAR ELEMENTOS / ELIMINARLOS
        Inventario<NaveEspacial> invNaves = new Inventario<>();
        invNaves.addTo(new NaveEspacial(1, "USS Enterprise", 10, Categoria.EXPLORACION));
        invNaves.addTo(new NaveEspacial(0, "Falcon Plane", 2, Categoria.MILITAR));
        invNaves.addTo(new NaveEspacial(2, "TIE Fighter", 22, Categoria.EXPLORACION));
        invNaves.addTo(new NaveEspacial(4, "Discovery One", 8, Categoria.CARGA));
        invNaves.addTo(new NaveEspacial(3, "X-Wing", 16, Categoria.CARGA));
        invNaves.addTo(new NaveEspacial(5, "UNSC aircraft", 5, Categoria.MILITAR));
        invNaves.addTo(new NaveEspacial(6, "add test",52, Categoria.EXPLORACION));
        
        invNaves.removeFrom(0);
        invNaves.showInv();


        separador();
//        FILTRAR NAVES POR CATEGORIA CARGA o NOMRE

//        invNaves.filterElements(n -> n.getCat() == Categoria.CARGA);
//        invNaves.showInv();


//        invNaves.filterElements( n -> n.getNombre().toLowerCase().contains("falcon") );
//        invNaves.showInv();
        
        
        separador();
//        ORDENAR POR ORDEN NAURAL (por id)
        invNaves.sortElements();
        invNaves.showInv();
        
        
        separador();
//        ORDENAR POR NOMBRE
        invNaves.sortElements( Comparator.comparing(NaveEspacial::getNombre));
        invNaves.showInv();

        
        separador();
//        GUARDAR EN ARCHIVO BINARIO
        invNaves.saveBin( FilePaths.BIN_FILE);
        
//        CARGAR INVENTARIO BINARIO
        List<NaveEspacial> loadInv = Inventario.loadBin(FilePaths.BIN_FILE);
        System.out.println("Archivo cargado: ");
        loadInv.forEach(nave -> System.out.println(nave) );

//        GUARDAR CSV
        invNaves.guardarEnArchivo(FilePaths.CSV_FILE);
        
//        CARGAR CSV
        List<NaveEspacial> newCSV = Inventario.cargarCSV(FilePaths.CSV_FILE);
        
        
    }
    public static void separador(){
        System.out.println("-----------------------------------------------------------------");
    }
}
