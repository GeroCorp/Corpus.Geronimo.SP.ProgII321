package services;

import interfaces.Filter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import models.NaveEspacial;

/**
 *
 * @author Gerónimo
 */
public class Inventario<T> implements Serializable{
    
    private List<T> inv = new ArrayList<>();
    
    public void addTo (T el){
        if (el != null){
            inv.add(el);
        }
    }
    
    public void removeFrom (int index){
        if (!inv.isEmpty())
        {
            inv.remove(index);
        }
        
    }
    
    public void showInv(){
        System.out.println("Contenido del inventario: ");
        
        inv.forEach(System.out::println);
    }
    
    public void filterElements (Predicate<T> f){
        
        List<T> aux = new ArrayList<>();
        for(T t : inv){
            if(f.test(t)){
                aux.add(t); 
           }
        }
        inv = aux;
        
    }
    
    public void sortElements (){
         inv.sort((Comparator<? super T>) Comparator.naturalOrder());
    }
    public void sortElements (Comparator<T> criterio){
         inv.sort(criterio);
    }

    public  void saveBin(String path){
        
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(path))){
            
            out.writeObject(inv);
            
        } catch (IOException ex) {
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        }
        
    }
    
    public static <T> List<T> loadBin (String path){
        List<T> toReturn = null;
        
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(path))) {
        
            toReturn = (List<T>) in.readObject();
                        
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;   
    }
 
    
    public void guardarEnArchivo(String file) {
        File f = new File(file);

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))){
            
            for (T e: inv){
                if(e instanceof NaveEspacial p){
                    bw.write(p.toCSV()+"\n");
                }else{
                bw.write(e.toString() + "\n");
            }}
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
     public static List<NaveEspacial> cargarCSV (String path){
        File file = new File(path);
        List<NaveEspacial> toReturn = new ArrayList<>();
        
        try {BufferedReader bf = new BufferedReader(new FileReader(file));
            
            String line;
            bf.readLine();
            
            while((line = bf.readLine()) != null){
                
                if (line.endsWith("\n")){
                line = line.substring(line.length()-1);
                }
                
                toReturn.add(NaveEspacial.fromCSV(line));
                
            }
        }catch (IOException ex ) {
            System.out.println(ex.getMessage());        
        }
        
        return toReturn;   
    }
    
    
}
