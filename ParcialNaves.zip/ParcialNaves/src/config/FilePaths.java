package config;

public class FilePaths {
    public static final String FILES_PATH = "src/data/";
    public static final String CSV_FILE = FILES_PATH + "navesCsv.csv";
    public static final String BIN_FILE = FILES_PATH + "navesBin.bin";
}
