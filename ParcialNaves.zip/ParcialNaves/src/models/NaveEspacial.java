package models;

import config.Categoria;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class NaveEspacial implements Serializable, Comparable<NaveEspacial> {
    private static final Long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private int capacidadTripulacion;
    private Categoria cat;

    public NaveEspacial(int id, String nombre, int capacidadTripulacion, Categoria cat) {
        this.id = id;
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.cat = cat;
    }

    public Categoria getCat() {
        return cat;
    }

    public String getNombre() {
        return nombre;
    }

    
    
    
    @Override
    public String toString() {
        return "NaveEspacial{" + "id=" + id + ", nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", cat=" + cat + '}';
    }
    
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.nombre);
        return hash;
    }

    public String toCSV (){
        return id + "," +nombre+ ","+capacidadTripulacion+","+ cat.toString();
    }
    
    public static NaveEspacial fromCSV (String csv){
        NaveEspacial toReturn = null;
        
        String[] values = csv.split(",");
                
                if (values.length == 4){
                    int id = Integer.parseInt(values[0]);
                    String nombre = values[1];
                    int cap = Integer.parseInt(values[2]);
                    Categoria cat = Categoria.valueOf(values[3]);
                    
                    toReturn = new NaveEspacial(id, nombre, cap, cat);
                }
        
        return toReturn;
    }
    
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof String str){
            return nombre.equals(str);
        }
        if (obj instanceof NaveEspacial other){
            return this.id == other.id;
        }
        return false;
    }


    @Override
    public int compareTo(NaveEspacial n) {
        return this.id - n.id;
    }

    
    

    
    
    
    
    
    
}
